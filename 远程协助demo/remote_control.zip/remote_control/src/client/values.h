#ifndef VALUES_H
#define VALUES_H

extern int screen_width;
extern int screen_height;

extern bool control;

extern QString addr;
extern int rq_width;
extern int rq_height;

#endif // VALUES_H
